<?php require_once 'budget.php';?>
<?php  if(isset($_SESSION['megs'])):?>
<?php endif ?> 
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Client area</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Dashboard</h1>
			</div>
		</div><!--/.row-->
		
    <div class="form">
        <p>Hey, <?php echo $_SESSION['username']; ?>!</p>
        <p>Welcome to Penny Pocket!</p>
    </div>
	<form action="budget.php" method="POST">
	<div class="form-group">
         <label for="budgetValue">Set the Budget.</label>
         <input type="text" name="budget" class="form-control" id="budget" placeholder="Enter Amount" required >
         </div>
             <button type="submit" name="save" class="btn btn-primary btn-block">Save</button>
	</form>

	<?php 
                    if(isset($_SESSION['megs'])){
                        echo    "<div class='alert alert-{$_SESSION['msg_type']} alert-dismissible fade show ' role='alert'>
                                    <strong> {$_SESSION['megs']} </storng>
                                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                        <span aria-hidden='true'>&times;</span>
                                    </button>
                                </div>";
                    }
                ?>
    <h2 class="text-center">Budget : Rs. <?php echo $budgets?></h2></div>
	<div><h4>Total Expenses=Rs.<?php echo $expensestotal?>.</h4></div>
	<div> <h4> Total Income =Rs.<?php echo $Totlincome  ?>.</h4></div>
    <div><h2 class="text-center">Budget balance : Rs. <?php echo $balance;?></h2></div>

	<div ><h4>Today's(<?php echo $tdate?>) Expense =Rs.<?php 
	if($sum_today_expense==""){
							echo "0";
							} else {
								echo $sum_today_expense;
								}?></h4></div>
	<div ><h4>Yesterday's(<?php echo $ydate?>) Expense =Rs. <?php
	 if($sum_yesterday_expense==""){
							echo "0";
							} else {
								echo $sum_yesterday_expense;
								}?></h4></div>

    </div>

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
</body>
</html>
