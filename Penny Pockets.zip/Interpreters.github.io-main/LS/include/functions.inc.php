<?php
function emptyInputSignup($fullname, $username, $email, $password, $con_password)
{
    $result;
    if (empty($fullname) ||empty($username) ||empty($email) ||empty($password) ||empty($con_password)) {
        $result = true;
    }
    else{
        $result = false;
    }
  return $result;
}
function invalidname($fullname)
{
    $result;
    if (!preg_match("/^[a-zA-Z]*$/", $fullname)) {
        $result = true;
    }
    else{
        $result = false;
    }
  return $result;
}
function invalidUsername($username)
{
    $result;
    if (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
        $result = true;
    }
    else{
        $result = false;
    }
  return $result;
}
function invalidEmail($email)
{
    $result;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = true;
    }
    else{
        $result = false;
    }
  return $result;
}
function passwordMatch($password, $con_password)
{
    $result;
    if ($password !== $con_password) {
        $result = true;
    }
    else{
        $result = false;
    }
  return $result;
}
function usernameExists($conn, $username, $email)
{
    $sql = "SELECT * FROM users WHERE usersName = ? OR usersEmail = ?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        header("location: ../signup.php?error=statementError");
        exit(); 
    }
    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
    mysqli_stmt_execute($stmt);
    
    $resultData = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($resultData)){
        return $row;
    }
    else{
        $result = false;
        return $result;
    }
    mysqli_stmt_close($stmt);

}
function createUser($conn, $fullname, $username, $email, $password)
{
    $sql = "INSERT INTO users (fullName, usersName, usersEmail, usersPassword) VALUES (?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        header("location: ../signup.php?error=statementError");
        exit(); 
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "ssss", $fullname, $username, $email, $hashedPassword);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../login.php?error=none");
        exit();

}
function emptyInputLogin($username, $password)
{
    $result;
    if (empty($username) ||empty($password )) {
        $result = true;
    }
    else{
        $result = false;
    }
  return $result;
}

function loginUser($conn, $username, $password){
   $UIDexist = usernameExists($conn, $username, $username);

     if($UIDexist === false){
       header("location: ../login.php?error=wrongLogin");
       exit();
     }

     
      $paswordHashed = $UIDexist["usersPassword"];
      $checkedPassword = password_verify($password, $paswordHashed);

     if($checkedPassword === false){
        header("location: ../login.php?error=wrongLogin2");
        exit();
     }
     else if($checkedPassword === true){
         session_start();
         $_SESSION["userid"] = $UIDexist["usersID"];
         $_SESSION["username"] = $UIDexist["usersName"];
         header("location: ../signup.php");
       // echo $paswordHashed;
         exit();
     }
}    