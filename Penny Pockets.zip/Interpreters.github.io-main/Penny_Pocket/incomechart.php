
<?php
session_start();
require 'include/db.php';
if (strlen($_SESSION["userid"]==0)) {
  header('location:logout.php');
  } else{
 $userid=$_SESSION["userid"];
 $query="SELECT name,sum(amount) as Type FROM income WHERE userID=$userid GROUP BY name";
 $result=mysqli_query($conn,$query);
  }?>

<!DOCTYPE html>
<html lang="en-US">
<body>
<div id="piechart" style="width:900px;"></div>
</div>
                <div class="dashboard justify-content-center">
                <p><a href="income.php">Go BACK</a></p>
                </div>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['name', 'Type'],
  <?php
 while($row=mysqli_fetch_array($result))
 {
   echo"['".$row["name"]."',".$row["Type"]."],";
 }?>
]);

  var options = {'title':'My Incomes', 'width':600, 'height':800,'pieHole':0.5};

  //to show the chart inside.
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>

</body>
</html>
