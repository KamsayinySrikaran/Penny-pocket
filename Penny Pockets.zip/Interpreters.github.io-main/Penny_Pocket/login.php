<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
      <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
<div class="image">
        <img src="img/img.jpeg" width= 100%></div>
        <form action="include/login.inc.php" method="POST">
         <div class="container2">
           <label>Username/Email:</label>
           <input type="text" placeholder="Enter username/email" name="username" required>
           <label>Password:</label>
           <input type="password" placeholder="Enter your password" name="password" required>
           <!--<a href="link">forget your username or password?</a>
            -->
            
           <button type="submit" name="submit">Log In</button>
            <!--
           <input type="checkbox" checked="checked"> Remember username
            -->
           Don't have an account?<a href="signup.php">Sign up</a>

         </div>
        </form>
        <?php 
        if(isset($_GET["error"])){
          if($_GET["error"]=="emptyinput"){
              echo "<p>All necessary fields must be filled</p>";
          }
          else if($_GET["error"]=="wrongLogin"){
            echo "<p>incorrect login ..Try again!</p>";
          }
          else if($_GET["error"]=="wrongLogin2"){
            echo "<p>incorrect login warning..Try again!</p>";
          }
        } 
        ?>
        
         <button class='button1'>
          <a href='##HOME##'>BACK TO HOME</a>
         </button>
       
    </body>
        
</html>
      
    
  