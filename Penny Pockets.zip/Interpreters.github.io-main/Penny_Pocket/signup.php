<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
    <link rel= "stylesheet" href="css/style-signup.css">
    </head>

    <body>
    <div class="image">
        <img src="img/pic2.jpg" width= 100%></div>
    <div class="container2">
    
        <form action="include/signup.inc.php" method="post">
         
           <label>User name:</label>
           <input type="text" placeholder="Enter username" name="username" required >
           <label>Email:</label>
           <input type="text" placeholder="Enter Email" name="email" required>
           <label>Password</label>
           <input type="password" placeholder="Enter your password" name="password" required>
           <label>Confirm Password</label>
           <input type="password" placeholder="Confirm password" name="confirm_password" required>
           <div class="login_button">
           <button type="submit" name="submit">Sign up</button>
           Already have an account?<a href="login.php">Log In</a>
          </div>
        </form>
    </div>
      
    <?php 
      if(isset($_GET["error"])){
          if($_GET["error"]=="emptyinput"){
              echo "<p>All necessary fields must be filled</p>";
          }
          else if($_GET["error"]=="invalidUsername"){
            echo "<p>use a proper username!</p>";
          }
          else if($_GET["error"]=="invalidEmail"){
            echo "<p>use a valid email address!</p>";
          }
          else if($_GET["error"]=="passwordsDonotMatch"){
            echo "<p>passwords donot match!</p>";
          }
          else if($_GET["error"]=="usernameTaken"){
            echo "<p>User name already exist!</p>";
          }
          else if($_GET["error"]=="usernameTaken"){
            echo "<p>User name already exist!</p>";
          }
          else if($_GET["error"]=="statementError"){
            echo "<p>something went wrong...try again!</p>";
          }
          else if($_GET["error"]=="none"){
            echo "<p>You have signed up!</p>";
          }

          
          

      }

    ?>
       
         <button class='button1'>
          <a href='##HOME##'>BACK TO HOME</a>
         </button>
       
    </body>
        

</html>