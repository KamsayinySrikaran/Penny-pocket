<?php

if(isset($_POST["submit"])){
  
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $con_password = $_POST["confirm_password"];
    
    require_once 'db.php';
    require_once 'functions.inc.php';

    if(emptyInputSignup($username, $email, $password, $con_password)!==false){
        header("location: ../signup.php?error=emptyinput");
        exit();
    }
    if(invalidUsername($username)!==false){
        header("location: ../signup.php?error=invalidUsername");
        exit();
    } 
    if(invalidEmail($email)!==false){
        header("location: ../signup.php?error=invalidEmail");
        exit();
    }
     if(passwordMatch($password, $con_password)!==false){
        header("location: ../signup.php?error=passwordsDonotMatch");
        exit();
    }
    if(usernameExists($conn, $username, $email)!==false){
        header("location: ../signup.php?error=usernameTaken");
        exit();
    }
    
    createUser($conn, $username, $email, $password);


}
else{
    header("location: ../signup.php");
    exit();
}
?>
