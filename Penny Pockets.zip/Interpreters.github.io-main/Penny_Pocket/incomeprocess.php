<?php
session_start();
require 'include/db.php';
if (strlen($_SESSION["userid"]==0)) {
  header('location:logout.php');
  } else{
// variable declaration

$Totlincome = 0;
$update = false;
$id=0;
$name = '';
$amount = '';
$userid=$_SESSION["userid"];


//store data
    if(isset($_POST['save'])){
       
        $income = $_POST['name'];
        $amount = $_POST['amount'];
        $date = $_POST['date'];


        $query = mysqli_query($conn, "INSERT INTO income (userID,name, amount, date) VALUE ('$userid','$income', '$amount','$date')"); 
        
        $_SESSION['message'] = "Recode has been saved !";
        $_SESSION['msg_type'] = "primary";

        header("location: income.php");
        

    }

    //calculate Total Income
    $result = mysqli_query($conn, "SELECT * FROM income  WHERE userID=$userid");
    while($row = $result->fetch_assoc()){
        $Totlincome= $Totlincome+ $row['amount'];
        $_SESSION['income']=$Totlincome;
    }

    //delete data

    if(isset($_GET['delete'])){
        $id = $_GET['delete'];

        $query = mysqli_query($conn, "DELETE FROM income WHERE id=$id");
        $_SESSION['message'] = "Recode has been Delete !";
        $_SESSION['msg_type'] = "danger";

        header("location: income.php");

    }


    //edit data

    if(isset($_GET['edit'])){
        $id = $_GET['edit'];
        $update = true;
        $result = mysqli_query($conn, "SELECT * FROM income WHERE id=$id");

      
        if( mysqli_num_rows($result) == 1){
            $row = $result->fetch_assoc();
            $name = $row['name'];
            $amount = $row['amount'];
            $date = $row['date'];
        }
    
    }

    //update data

    if(isset($_POST['update'])){
        $id = $_POST['id'];
        $income = $_POST['name'];
        $amount = $_POST['amount'];
        $date = $_POST['date'];

        $query = mysqli_query($connn, "UPDATE income SET name='$income', amount='$amount', date='$date' WHERE id='$id'");
        $_SESSION['message'] = "Recode has been Update !";
        $_SESSION['msg_type'] = "success";
        header("location: income.php");
    }

  }
?>