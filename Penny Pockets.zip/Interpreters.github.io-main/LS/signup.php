<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,300,400,500,700,900" rel="stylesheet">
    <title>Penny Pocket_Home</title>
    <link rel= "stylesheet" href="css/style-signup.css?v=567987">
    </head>

    <body>

      <div class="image">
        <img src="img/pic13.png" width=1000px height=800px>

        <style>
          
.image{

position:fixed;

margin-top: -1.5cm;
margin-left: 6.5cm;

}</style>
      </div>
    <div class="container2">
    <div class="heading"><p>Register</p></div>
    <div class="conta">
 
        <form action="include/signup.inc.php" method="post">
         
           <label>Full name:</label>
           <input type="text" placeholder="Enter your fullname" name="fullname" >
           <label>User name:</label>
           <input type="text" placeholder="Enter your username" name="username" >
           <label>Email:</label>
           <input type="text" placeholder="Enter your Email Address" name="email" required>
           <label>Password</label>
           <input type="password" placeholder="Enter your password" name="password" required>
           <label>Confirm Password</label>
           <input type="password" placeholder="Confirm your password" name="confirm_password" required>
           <div class="login_button">
           <button type="submit" name="submit">Sign up</button>
           Already have an account?<a href="login.php"><b><div class="sign">Log In</div></b></a>
          </div>
        </form>
    </div>
    </div>
    <button class='button1'>
          <a href="">HOME >>></a>
         </button>
  
      
    <?php 
      if(isset($_GET["error"])){
          if($_GET["error"]=="emptyinput"){
              echo "<p>All necessary fields must be filled</p>";
          }
          else if($_GET["error"]=="invalidname"){
            echo "<p>use a proper name!</p>";
          }
          else if($_GET["error"]=="invalidUsername"){
            echo "<p>use a proper username!</p>";
          }
          else if($_GET["error"]=="invalidEmail"){
            echo "<p>use a valid email address!</p>";
          }
          else if($_GET["error"]=="passwordsDonotMatch"){
            echo "<p>passwords donot match!</p>";
          }
          else if($_GET["error"]=="usernameTaken"){
            echo "<p>User name already exist!</p>";
          }
          else if($_GET["error"]=="usernameTaken"){
            echo "<p>User name already exist!</p>";
          }
          else if($_GET["error"]=="statementError"){
            echo "<p>something went wrong...try again!</p>";
          }
          else if($_GET["error"]=="none"){
            echo "<p>You have signed up!</p>";
          }

          
          

      }

    ?>
       
       
       
    </body>
        

</html>